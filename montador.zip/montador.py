import re 

#importação do código fonte
codigobn = ("	addi $s0,$zero,5 \n"
	"	add $a0,$s0,$zero\n"
	"	jal fato\n"
	"	\n"
	"	add $s1,$v0,$zero\n"
	"	j exit\n"
	"#functions\n"
	"#fatorial{\n"
	"fato:	addi $sp,$sp,-8\n"
	"	sw $t0,4($sp)\n"
	"	sw $a0,($sp)\n"
	"	bne $a0,$zero,recur\n"
	"	addi $v0,$zero,1\n"
	"	j fimFato\n"
	"recur:	add $t0,$a0,$zero\n"
	"	\n"
	"	addi $a0,$a0,-1\n"
	"	addi $sp, $sp, -4\n"
	"	sw $ra,0($sp)\n"
	"	jal fato\n"
	"	lw $ra,0($sp)\n"
	"	addi $sp, $sp, 4\n"
	"	add $v0,$t0,$v0\n\n"
	"fimFato:lw $a0,0($sp)\n"
	"	lw $t0,4($sp)\n"
	"	addi $sp, $sp, 8\n"
	"	jr $ra\n"
	"#}\n"
	"exit:")


#limpeza e formatação do código fonte
regex = [( r"#.*$" , "" ),
( r"[\n\r][ \t\n\r]*[\n\r]?" , "\n" ),( r"[ \t\n\r]:[ \t\n\r]" , ": " ),
( r"[ \t]+" , " " ), ( r"[ \t\r\n]+\$" , " $" ), ( r"[ \t\r\n]*,[ \t\r\n]*" , "," ),( r"\nj[\n\r\t ]+" , "\nj " ), 
( r"\njal[\n\r\t ]+" , "\njal " ) 
]


for r in regex:
	codigobn=re.sub(r[0],r[1],codigobn,0,re.MULTILINE) 

codigobn = codigobn.strip()#o strip eu ja tinha colocado aqui
#print(codigobn) 

# divisão de instruções
divisao=codigobn.split('\n') 
#print(divisao)

#registro de rótulos
regex = r"([a-zA-Z0-9_]+):"
rotulos = {}
for i, instruction in zip(range(len(divisao)), divisao):
  matches = re.search(regex, instruction)
  if matches:
    rotulos[matches.group(1)] = i
    divisao[i] = re.sub(regex, "", instruction,0, re.MULTILINE)
  divisao[i] = divisao[i].strip()

# print(divisao)
# print(len(divisao))
#print(rotulos)

# reconhecimento de instruções
regex = r"(([a-zA-Z][a-zA-Z0-9_]*) (\$[a-zA-Z0-9_]+)(,(\$[a-zA-Z0-9_]+),(\$[a-zA-Z0-9_]+))?$)|(([a-zA-Z][a-zA-Z0-9_]*) (\$[a-zA-Z0-9_]+),(((\$[a-zA-Z0-9_]+),(-?[0-9]+)$)|((-?[0-9])?\((\$[a-zA-Z0-9_]+)\))|((\$[a-zA-Z0-9_]+),([a-zA-Z][a-zA-Z0-9_]*))))|(([a-zA-Z][a-zA-Z0-9_]*) ([a-zA-Z][a-zA-Z0-9_]*))"

registradores = ['$zero','$at', '$v0', '$v1', '$a0', '$a1', '$a3' ,'$t0' , '$t1' , '$t2', '$t3', '$t4', '$t5', '$t6', '$t7', '$s0', '$s1', '$s2', '$s3', '$s4', '$s5', '$s6', '$s7', 't8', '$t9', '$k0', '$k1', '$gp', '$sp', '$fp', '$ra']

intrR=['add','addu','sub','subu','mult','multu','div','divu','syscall','slt','sltu','sll','sllv','jr','jalr','and','or','nor','mfhi','mflo','sra','srav']
intrI=['addi','addu','lw','bne','beq','slti','sltiu','lh','lhu','lb','lbu','sw','sh','sw','lui','ori','andi','xori']
intrJ=['j','jal']

opcI=[ 0x04, 0x05,0x08, 0x09,0x0a, 0x0b, 0x0c,0x0d,0x0e,0x0f,0x20,0x21,0x23,0x24,0x025 ,0x28,0x29,0x2b]
opcJ=[0x02,0x03]
funR=[0x2a, 0x2b, 0x00, 0x04, 0x02, 0x06, 0x03, 0x07, 0x08, 0x09, 0x0c,0x20, 0x21, 0x22, 0x23, 0x18, 0x19, 0x1a, 0x1b, 0x10, 0x12, 0x24, 0x25, 0x26, 0x27]

inst_part = []

for i, instruction in zip(range(len(divisao)), divisao):
  inst = {}
  if instruction != '':
    matches = re.search(regex, instruction)
    if matches:
      if matches.group(1): # tipo r
        #reconhecimento do texto
        inst['type'] = "R"
        inst['mne'] = matches.group(2)
        inst['rs'] = matches.group(5) or "$zero"
        inst['rt'] = matches.group(6) or "$zero"
        inst['rd'] = matches.group(3)
        inst['shamt'] = ""

        #conversao pra numeros
        inst['func'] = funR[intrR.index(inst['mne'])]
        inst['opcode'] = 0
        inst['shamt'] = 0
        inst['rs'] = registradores.index(inst['rs']) #querendo converter Rs para inteiro 
        inst['rt']=registradores.index(inst['rt'])
        inst['rd']=registradores.index(inst['rd'])
        ########################################### MONTAGEM 
        #[opcode, rs, rt, rd, shamt, func]
        #[6, 5, 5, 5, 5, 6]
        #[31-26, 25-21, 20-16, 15-11, 10-6, 5-0]
        #0x3f   0b[0011][1111]
        #0x1f   0b[0001][1111]
        # op 1010100000000000000000000
        # rs 0000001010100000000000000
        # rd 00000000000101010000000000
        #
        #
        # cd 1010101010110101
        inst['opcode'] = inst['opcode'] & 0x3f << 26 #0x&3f pra garatntir que o restante do numero seja zero, 26 pra indicar ONDE o opcode se inicia 
        inst['rs'] = (inst['rs'] & 0x1f) << 21
        inst['rt'] = (inst['rt'] & 0x1f) << 16
        inst['rd'] = (inst['rd'] & 0x1f) << 11
        inst['shamt'] = (inst['shamt'] & 0x1f) << 6
        inst['func'] = (inst['func'] & 0x3f) << 0
        inst['code'] = inst['opcode'] | inst['rs'] | inst['rt'] | inst['rd'] | inst['shamt'] | inst['func']

      elif matches.group(7): # tipo i
        inst['type'] = "I"
        inst['mne'] = matches.group(8)
        inst['rs'] = matches.group(9)
        if matches.group(11): # mne $t0, $t1, -5
          inst['class'] = 1
          inst['rt'] = matches.group(12)
          inst['imm'] = int(matches.group(13))
        elif matches.group(14): # mne $t0, -4($t1)
          inst['class'] = 2
          inst['rt'] = matches.group(16)
          inst['imm'] = int(matches.group(15) or 0)
        elif matches.group(17): # mne $t0, $t1, label
          inst['class'] = 3
          inst['rt'] = matches.group(18)
          inst['imm'] = rotulos[matches.group(19)] - i
        
          #A diferença para os saltos com jump e os saltos com branch é que o jump guarda o endereço absoluto, e o branch guarda o endereço relativo à instrução atual. Então pra isso, pra salvar o valor na instrução, eu devo pegar o endereço a instrução pra onde eu quero ir e subtrair o endereço da instrução atual
        inst['opcode']=  opcI[intrI.index(inst['mne'])]
        inst['rs'] = registradores.index(inst['rs'])
        inst['rt']=registradores.index(inst['rt']) 

        ####################################### MONTAGEM 
        inst['opcode'] = (inst['opcode'] & 0x3f) << 26
        inst['rs'] = (inst['rs'] & 0x1f) << 21
        inst['rt'] = (inst['rt'] & 0x1f) << 16
        inst['imm']= (inst['imm'] &0xffff) << 0  
        #[1111][1111][1111][1111]
        #  0xFFFF

        inst['code']= inst['opcode'] | inst['rs'] | inst['rt'] | inst['imm']


      elif matches.group(20): # tipo j
        inst['type'] = "J"
        inst['mne'] = matches.group(21)
        inst['addr'] = rotulos[matches.group(22)]
        #conversao pra numeros
        inst['opcode']=  opcJ[intrJ.index(inst['mne'])]
        #montagem
        inst['opcode'] = (inst['opcode'] & 0x3f) << 26 
        inst['addr'] = (inst ['addr'] & 0x3ffffff ) << 0  
        #[0011][1111][1111][1111][1111][1111][1111]

        inst['code'] = inst['opcode'] | inst['addr']
        
    else:
        raise Exception("Instrução não reconhecida: {}".format  (instruction))
    inst_part.append(inst)
  else:
    pass

inst_code = ['{:032b}'.format(x['code']) for x in inst_part]
#print(inst_code)

regex = r"([01]{8})([01]{8})([01]{8})([01]{8})"

ret = ""
for instrucao in inst_code:
  matches = re.search(regex, instrucao)
  ret += matches.group(4)+"\n"+matches.group(3)+"\n"+matches.group(2)+"\n"+matches.group(1)+"\n"

ret = ret[:-1]

arqhexa=open('codigobn','a')
arqhexa.truncate(0)
arqhexa.write(ret)
arqhexa.close()


        






    



